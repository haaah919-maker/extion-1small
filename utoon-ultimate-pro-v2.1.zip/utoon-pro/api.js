// Utoon Ultimate Pro v2.1 - API Module
window.UtoonAPI = (function() {
    const CFG = window.UtoonConfig;

    async function fetchJSON(url, retries = 2) {
        for (let i = 0; i <= retries; i++) {
            try {
                const res = await fetch(url, { headers: { 'Accept': 'application/json' }, cache: 'no-cache' });
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                return await res.json();
            } catch (e) {
                if (i === retries) throw e;
                await new Promise(r => setTimeout(r, 500 * (i + 1)));
            }
        }
    }

    async function fetchMangaInfo(mangaSlug) {
        const data = await fetchJSON(`${CFG.API_BASE}/mangas/slug/${mangaSlug}/`);
        const mangaInfo = (data.mangas || [])[0];
        if (!mangaInfo) return null;
        let chapters = mangaInfo.capitulos || [];
        chapters.reverse();
        return { mangaInfo, chapters };
    }

    async function fetchChapterImages(chapterId) {
        const data = await fetchJSON(`${CFG.API_BASE}/capitulo/${chapterId}/`);
        const rawList = data.imagenes || data.images || [];
        return rawList.map(item => typeof item === 'string' ? item : (item.src || '')).filter(Boolean);
    }

    // Fallback: generate up to 300 possible image URLs
    function buildFallbackUrls(mangaSlug, chapterSlug) {
        const urls = [];
        for (let i = 1; i <= 300; i++) {
            const n = i.toString().padStart(2, '0');
            urls.push(`${CFG.BASE_URL}/${mangaSlug}/${chapterSlug}/${n}.jpg`);
            urls.push(`${CFG.BASE_URL}/${mangaSlug}/${chapterSlug}/${n}.webp`);
        }
        return urls;
    }

    async function getAllChapterImages(mangaSlug, chapterSlug, currentChapterId) {
        if (currentChapterId) {
            try {
                const imgs = await fetchChapterImages(currentChapterId);
                if (imgs && imgs.length > 0) return imgs;
            } catch (e) {
                console.warn("[Utoon] API image fetch failed, using fallback:", e);
            }
        }
        return buildFallbackUrls(mangaSlug, chapterSlug);
    }

    async function fetchImageBlob(src, timeout = 20000) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeout);
        try {
            const res = await fetch(src, { signal: controller.signal, mode: 'cors' });
            clearTimeout(timer);
            if (!res.ok) return null;
            return await res.blob();
        } catch (e) {
            clearTimeout(timer);
            return null;
        }
    }

    const preloadCache = new Map();
    function preloadImage(src) {
        if (preloadCache.has(src)) return preloadCache.get(src);
        const img = new Image();
        const promise = new Promise(resolve => {
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
            img.src = src;
        });
        preloadCache.set(src, promise);
        if (preloadCache.size > 60) {
            const k = preloadCache.keys().next().value;
            preloadCache.delete(k);
        }
        return promise;
    }

    return { fetchJSON, fetchMangaInfo, fetchChapterImages, getAllChapterImages, buildFallbackUrls, fetchImageBlob, preloadImage };
})();
