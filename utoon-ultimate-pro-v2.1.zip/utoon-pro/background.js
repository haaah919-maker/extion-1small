// Utoon Ultimate Pro v2.1 - Background Service Worker
chrome.runtime.onInstalled.addListener(() => {
    console.log("[Utoon v2.1] Installed.");
    chrome.storage.local.set({ remoteConfig: { smart_link: "https://discord.com/users/@threads" } });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url?.includes('utoon.net')) {
        // Auto-inject on chapter pages
        if (/utoon\.net\/manga\/[^/]+\/chapter-[^/]+\/?$/.test(tab.url)) {
            chrome.scripting.executeScript({
                target: { tabId },
                files: ['jspdf.min.js','jszip.min.js','config.js','api.js','effects.js','ui.js','download.js','settings.js','reader_logic.js']
            }).catch(err => console.warn("[Utoon] Auto-inject failed:", err));
        }
    }
});
