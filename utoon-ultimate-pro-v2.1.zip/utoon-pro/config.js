// Utoon Ultimate Pro v2.1 - Configuration & Constants
window.UtoonConfig = {
    BASE_URL: "https://utoon.net/wp-content/uploads/WP-manga/data",
    API_BASE: "https://utoon.net/wp-json/icmadara/v1",

    EXTENSION: { name: "Utoon Ultimate Pro", version: "2.1", author: "Utoon Team" },

    COLORS: {
        primary: "#a855f7", primaryDark: "#7c3aed", accent: "#db2777",
        success: "#22c55e", bgDark: "#0a0514", bgPanel: "rgba(10,5,25,0.95)",
        textMain: "#e2d9f3", textMuted: "#a0aec0", border: "rgba(168,85,247,0.3)",
        shadow: "rgba(168,85,247,0.25)", white: "#fff"
    },

    THEMES: {
        default:     { name: "🟣 Purple",  background: "linear-gradient(to bottom,#0a0514,#130a2a)", text: "#e2d9f3", accent: "#a855f7" },
        grey:        { name: "⚫ Grey",    background: "#212529",                                     text: "#e2d9f3", accent: "#a855f7" },
        black:       { name: "◼️ Black",   background: "#000",                                        text: "#e2d9f3", accent: "#a855f7" },
        cream:       { name: "📜 Cream",   background: "#f5f0e1",                                     text: "#2d2a26", accent: "#a855f7" },
        midnight:    { name: "🌌 Midnight",background: "linear-gradient(to bottom,#020617,#0f172a)",  text: "#cbd5e1", accent: "#38bdf8" },
        manga:       { name: "🖼️ Cover",   background: null,                                          text: "#e2d9f3", accent: "#a855f7" },
        custom:      { name: "🎨 Custom",  background: null,                                          text: "#e2d9f3", accent: "#a855f7" }
    },

    EFFECTS: {
        off:           { name: "No Effect 🚫",       icon: "🚫", particles: [],                             color: "rgba(255,255,255,0)",   type: "off"       },
        snow:          { name: "Snow ❄",             icon: "❄",  particles: ["❄","❅","❆","·"],            color: "rgba(255,255,255,0.9)", type: "fall"      },
        hearts:        { name: "Hearts ❤️",          icon: "❤",  particles: ["❤","💕","💖","💗"],          color: "rgba(255,90,130,0.95)", type: "rise"      },
        sparkles:      { name: "Sparkles ✨",         icon: "✨", particles: ["✦","✧","⭐","🌟"],           color: "rgba(255,240,200,0.95)",type: "float"     },
        sakura:        { name: "Sakura 🌸",          icon: "🌸", particles: ["🌸","🌺","🍃","❀"],          color: "rgba(255,200,230,0.95)",type: "sway"      },
        action:        { name: "Action 🔥",          icon: "🔥", particles: ["🔥","✦","⚡","💥"],          color: "rgba(255,160,90,0.95)", type: "ember"     },
        rain:          { name: "Rain 🌧️",            icon: "🌧", particles: ["💧"],                        color: "rgba(150,200,255,0.85)",type: "rain"      },
        blood_moon:    { name: "Blood Moon 🩸",      icon: "🩸", particles: ["🩸","🌕","🔴","🥀"],         color: "rgba(180,30,30,0.9)",   type: "fall_slow" },
        constellation: { name: "Constellation 🌌",   icon: "🌌", particles: ["✦","✧","⭐","🔹"],           color: "rgba(100,200,255,0.9)", type: "twinkle"   },
        petals:        { name: "Rose Petals 🥀",     icon: "🥀", particles: ["🥀","🌹","🍂","❀"],          color: "rgba(220,50,80,0.85)",  type: "sway"      },
        cyber:         { name: "Cyber 💠",           icon: "💠", particles: ["💠","🔷","▣","◈"],           color: "rgba(0,255,200,0.85)",  type: "matrix"    },
        dark_magic:    { name: "Dark Magic 🔮",      icon: "🔮", particles: ["🔮","✦","🌑","⚫"],          color: "rgba(148,0,211,0.9)",   type: "rise_slow" }
    },

    LAYOUT: { maxWidth: 850, borderRadius: 12 },

    AUTO_SCROLL: { min: 0, max: 15, step: 0.5, defaultValue: 0 },

    KEYS: {
        prevChapter:       ["ArrowLeft",  "KeyA"],
        nextChapter:       ["ArrowRight", "KeyD"],
        toggleAutoScroll:  ["Space"],
        fullscreen:        ["KeyF"],
        exit:              ["Escape"],
        toggleHeader:      ["KeyH"],
        zoomIn:            ["Equal", "NumpadAdd"],
        zoomOut:           ["Minus", "NumpadSubtract"],
        resetZoom:         ["KeyZ"]
    }
};
