// Utoon Ultimate Pro v2.1 - Download Module (ZIP / PDF Ultra-HD / Bulk)
window.UtoonDownload = (function() {
    const API = window.UtoonAPI;
    const CFG = window.UtoonConfig;

    // ── ZIP ──────────────────────────────────────────────────────────
    async function downloadZIP(imageUrls, chapterSlug, mangaSlug, onProgress = null) {
        if (!window.JSZip) { alert('JSZip not loaded'); return; }
        const zip = new JSZip();
        const folder = zip.folder(`${mangaSlug}_${chapterSlug}`);
        let completed = 0;

        for (let i = 0; i < imageUrls.length; i++) {
            try {
                const blob = await API.fetchImageBlob(imageUrls[i]);
                if (!blob) continue;
                const ext = imageUrls[i].endsWith('.webp') ? 'webp' : 'jpg';
                folder.file(`page_${String(i+1).padStart(3,'0')}.${ext}`, blob);
                completed++;
                if (onProgress) onProgress(completed, imageUrls.length);
            } catch (e) { console.warn('ZIP img skip', i, e); }
        }

        if (completed === 0) { alert('No images downloaded'); return; }
        const content = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(content);
        a.download = `${mangaSlug}_${chapterSlug}.zip`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 6000);
    }

    // ── PDF (Ultra-HD, lossless PNG) ─────────────────────────────────
    async function downloadPDF(imageUrls, chapterSlug, mangaSlug, btnElement = null) {
        if (!window.jspdf?.jsPDF) { alert('jsPDF not loaded'); return; }
        const { jsPDF } = window.jspdf;

        if (btnElement) {
            btnElement.disabled = true;
            btnElement._orig = btnElement.innerHTML;
            btnElement.innerHTML = '⏳ جاري...';
        }

        try {
            const images = Array.from(document.querySelectorAll('#img-container img'))
                .filter(img => img.complete && img.naturalWidth > 10);
            if (images.length === 0) { alert('ماكو صور للتحميل!'); return; }

            let pdf = null;
            for (let i = 0; i < images.length; i++) {
                const img = images[i];
                if (btnElement) btnElement.innerHTML = `⏳ ${i+1}/${images.length}`;

                const resp = await fetch(img.src, { mode: 'cors' });
                const blob = await resp.blob();
                const bmp  = await createImageBitmap(blob);

                const c = document.createElement('canvas');
                c.width  = bmp.width;
                c.height = bmp.height;
                const ctx = c.getContext('2d', { alpha: false });
                ctx.imageSmoothingEnabled = false;  // preserve original pixels
                ctx.drawImage(bmp, 0, 0);
                bmp.close();

                // PNG = lossless, no quality loss at all
                const dataUrl = c.toDataURL('image/png', 1.0);
                const w = c.width, h = c.height;
                const ori = w > h ? 'landscape' : 'portrait';

                if (i === 0) {
                    pdf = new jsPDF({ orientation: ori, unit: 'px', format: [w, h],
                                      compress: false, hotfixes: ['px_scaling'] });
                } else {
                    pdf.addPage([w, h], ori);
                }
                pdf.addImage(dataUrl, 'PNG', 0, 0, w, h, '', 'NONE');
            }

            pdf.setProperties({
                title:   `${mangaSlug} - ${chapterSlug}`,
                subject: 'Manga Chapter - Ultra HD',
                author:  CFG.EXTENSION.name,
                creator: `${CFG.EXTENSION.name} v${CFG.EXTENSION.version}`
            });
            pdf.save(`${mangaSlug}_${chapterSlug}_UHD.pdf`);

        } catch (err) {
            console.error(err);
            alert('فشل PDF: ' + err.message);
        } finally {
            if (btnElement) { btnElement.disabled = false; btnElement.innerHTML = btnElement._orig || '📄 PDF'; }
        }
    }

    // ── Bulk ZIP ─────────────────────────────────────────────────────
    async function downloadBulkZIP(chapters, mangaSlug, onProgress = null) {
        if (!window.JSZip) { alert('JSZip not loaded'); return; }
        if (!chapters?.length) { alert('No chapters selected'); return; }

        const masterZip = new JSZip();
        let total = 0, done = 0;

        for (const ch of chapters) {
            try {
                if (onProgress) onProgress(`↓ ${ch.slug}…`, done, total);
                const imgs = await API.getAllChapterImages(mangaSlug, ch.slug, ch.id_capitulo);
                if (!imgs?.length) continue;
                const folder = masterZip.folder(ch.slug);
                for (let i = 0; i < imgs.length; i++) {
                    const blob = await API.fetchImageBlob(imgs[i]);
                    if (!blob) continue;
                    const ext = imgs[i].endsWith('.webp') ? 'webp' : 'jpg';
                    folder.file(`page_${String(i+1).padStart(3,'0')}.${ext}`, blob);
                    done++; total = Math.max(total, done + (imgs.length - i));
                    if (onProgress) onProgress(null, done, total);
                }
            } catch (e) { console.warn('Bulk skip', ch.slug, e); }
        }

        if (done === 0) { alert('No images downloaded'); return; }
        const content = await masterZip.generateAsync({ type: 'blob', compression: 'DEFLATE' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(content);
        a.download = `${mangaSlug}_Bulk_${chapters.length}ch.zip`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 12000);
    }

    return { downloadZIP, downloadPDF, downloadBulkZIP };
})();
