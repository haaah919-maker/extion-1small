// Utoon Ultimate Pro v2.1 - Canvas-Based Visual Effects Module
window.UtoonEffects = (function() {
    const CFG = window.UtoonConfig;
    let canvas = null, ctx = null, animFrame = null;
    let particles = [], currentType = 'off', effectLayerDOM = null;

    function init(containerId) {
        effectLayerDOM = document.getElementById(containerId);
        if (!effectLayerDOM) return;
        _createCanvas();
        window.addEventListener('resize', resizeCanvas);
    }

    function _createCanvas() {
        if (!effectLayerDOM) return;
        canvas = document.createElement('canvas');
        canvas.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:10000000;';
        effectLayerDOM.appendChild(canvas);
        ctx = canvas.getContext('2d');
        resizeCanvas();
    }

    function resizeCanvas() {
        if (!canvas) return;
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    function clearEffects() {
        if (animFrame) { cancelAnimationFrame(animFrame); animFrame = null; }
        particles = [];
        if (ctx && canvas) ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (effectLayerDOM) effectLayerDOM.innerHTML = '';
        canvas = null; ctx = null;
    }

    class Particle {
        constructor() { this.reset(true); }

        reset(init = false) {
            const defs = CFG.EFFECTS[currentType] || {};
            const W = canvas ? canvas.width : window.innerWidth;
            const H = canvas ? canvas.height : window.innerHeight;
            this.w = W; this.h = H;
            this.x = Math.random() * W;
            this.y = init ? Math.random() * H : -30;
            this.size = Math.random() * 4 + 2;
            this.opacity = Math.random() * 0.7 + 0.3;
            this.speedX = (Math.random() - 0.5) * 1.2;
            this.speedY = Math.random() * 1.5 + 0.5;
            this.rotation = Math.random() * Math.PI * 2;
            this.rotationSpeed = (Math.random() - 0.5) * 0.03;
            this.life = 1;
            this.decay = Math.random() * 0.003 + 0.0005;

            switch (defs.type) {
                case 'fall':
                    if (!init) this.y = -20;
                    this.speedY = Math.random() * 2.5 + 1;
                    this.speedX = (Math.random() - 0.5) * 1;
                    this.size = Math.random() * 5 + 2;
                    break;
                case 'fall_slow':
                    if (!init) this.y = -20;
                    this.speedY = Math.random() * 0.8 + 0.3;
                    this.speedX = (Math.random() - 0.5) * 0.6;
                    this.size = Math.random() * 6 + 3;
                    break;
                case 'rise':
                case 'rise_slow':
                    if (!init) this.y = H + 20;
                    this.speedY = -(Math.random() * (defs.type === 'rise_slow' ? 0.8 : 1.8) + 0.5);
                    this.speedX = Math.sin(Math.random() * Math.PI * 2) * 0.8;
                    this.size = Math.random() * 5 + 3;
                    break;
                case 'float':
                    this.speedY = (Math.random() - 0.5) * 0.5;
                    this.speedX = (Math.random() - 0.5) * 0.5;
                    this.size = Math.random() * 3 + 1;
                    if (init) this.y = Math.random() * H;
                    break;
                case 'sway':
                    if (!init) this.y = -20;
                    this.speedY = Math.random() * 1.5 + 0.5;
                    this.swayAmp = Math.random() * 40 + 20;
                    this.swaySpd = Math.random() * 0.02 + 0.01;
                    this.swayOff = Math.random() * Math.PI * 2;
                    this.size = Math.random() * 5 + 3;
                    break;
                case 'ember':
                    if (!init) this.y = H + 10;
                    this.speedY = -(Math.random() * 2.5 + 0.8);
                    this.speedX = (Math.random() - 0.5) * 2.5;
                    this.size = Math.random() * 4 + 1;
                    this.life = Math.random() * 0.5 + 0.5;
                    break;
                case 'rain':
                    if (!init) this.y = -30;
                    this.speedY = Math.random() * 18 + 12;
                    this.speedX = (Math.random() - 0.5) * 0.8;
                    this.length = Math.random() * 18 + 10;
                    this.size = Math.random() * 1.5 + 0.5;
                    break;
                case 'twinkle':
                    this.speedY = (Math.random() - 0.5) * 0.15;
                    this.speedX = (Math.random() - 0.5) * 0.15;
                    this.size = Math.random() * 2.5 + 0.5;
                    this.twinkleSpd = Math.random() * 0.06 + 0.02;
                    if (init) this.y = Math.random() * H;
                    break;
                case 'matrix':
                    if (!init) this.y = -20;
                    this.x = Math.floor(Math.random() * (W / 14)) * 14;
                    this.speedY = Math.random() * 4 + 2;
                    this.size = 14;
                    this.char = ['0','1','░','▒','▓','█','▣','◈'][Math.floor(Math.random()*8)];
                    break;
            }
        }

        update() {
            const defs = CFG.EFFECTS[currentType] || {};
            switch (defs.type) {
                case 'sway':
                    this.y += this.speedY;
                    this.x += Math.sin(this.y * this.swaySpd + this.swayOff) * 0.6;
                    this.rotation += this.rotationSpeed;
                    break;
                case 'twinkle':
                    this.opacity = 0.2 + Math.abs(Math.sin(Date.now() * this.twinkleSpd)) * 0.8;
                    this.x += this.speedX; this.y += this.speedY;
                    break;
                case 'matrix':
                    this.y += this.speedY;
                    this.life -= 0.005;
                    break;
                default:
                    this.x += this.speedX; this.y += this.speedY;
                    this.rotation += this.rotationSpeed;
                    break;
            }
            this.life -= this.decay;
            const H = canvas ? canvas.height : window.innerHeight;
            const W = canvas ? canvas.width : window.innerWidth;
            if (this.life <= 0 || this.y > H + 60 || this.y < -60 || this.x < -60 || this.x > W + 60) {
                this.reset(false);
            }
        }

        draw(c) {
            const defs = CFG.EFFECTS[currentType] || {};
            const color = defs.color || "rgba(255,255,255,0.9)";
            c.save();
            c.globalAlpha = Math.max(0, this.opacity);
            c.translate(this.x, this.y);
            c.rotate(this.rotation);
            c.fillStyle = color;
            c.strokeStyle = color;

            switch (defs.type) {
                case 'rain':
                    c.lineWidth = this.size;
                    c.beginPath(); c.moveTo(0,0); c.lineTo(this.speedX*1.5, this.length); c.stroke();
                    break;
                case 'ember':
                    c.beginPath(); c.arc(0,0,this.size,0,Math.PI*2); c.fill();
                    c.shadowBlur = 12; c.shadowColor = color;
                    break;
                case 'matrix':
                    c.font = `${this.size}px monospace`;
                    c.fillStyle = `rgba(0,255,200,${Math.max(0,this.life)})`;
                    c.shadowBlur = 6; c.shadowColor = '#00ffc8';
                    c.fillText(this.char, 0, 0);
                    break;
                case 'twinkle': {
                    c.beginPath();
                    for (let i = 0; i < 8; i++) {
                        const r = (i%2===0) ? this.size*2.5 : this.size;
                        const a = (Math.PI/4)*i;
                        const px = Math.cos(a)*r, py = Math.sin(a)*r;
                        if(i===0) c.moveTo(px,py); else c.lineTo(px,py);
                    }
                    c.closePath(); c.fill();
                    c.shadowBlur = 10; c.shadowColor = color;
                    break;
                }
                default: {
                    const g = c.createRadialGradient(0,0,0,0,0,this.size*2.5);
                    g.addColorStop(0, color.replace(/[\d.]+\)$/,'0.85)'));
                    g.addColorStop(1, color.replace(/[\d.]+\)$/,'0)'));
                    c.beginPath(); c.arc(0,0,this.size*2.5,0,Math.PI*2);
                    c.fillStyle = g; c.fill();
                    c.beginPath(); c.arc(0,0,this.size*0.6,0,Math.PI*2);
                    c.fillStyle = color; c.fill();
                    break;
                }
            }
            c.restore();
        }
    }

    function animate() {
        if (!ctx || currentType === 'off') return;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (const p of particles) { p.update(); p.draw(ctx); }
        animFrame = requestAnimationFrame(animate);
    }

    function startEffect(type) {
        clearEffects();
        currentType = type || 'off';
        if (currentType === 'off') return;
        const defs = CFG.EFFECTS[currentType];
        if (!defs) return;

        if (effectLayerDOM) { _createCanvas(); }

        const counts = { snow:130, hearts:45, sparkles:65, sakura:55, action:90,
                         rain:220, blood_moon:35, constellation:75, petals:50, cyber:110, dark_magic:55 };
        const count = counts[currentType] || 60;
        for (let i = 0; i < count; i++) particles.push(new Particle());

        animate();
        if (typeof chrome !== 'undefined' && chrome.storage) chrome.storage.local.set({ savedEffect: type });
    }

    return { init, startEffect, clearEffects, getCurrentType: () => currentType };
})();
