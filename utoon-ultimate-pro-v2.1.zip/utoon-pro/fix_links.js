// Utoon Ultimate Pro v2.1 - Chapter Link Fixer
(function() {
    function injectGhostButtons() {
        if (!window.location.href.includes('/manga/')) return;
        const parts = window.location.pathname.split('/').filter(Boolean);
        const mangaSlug = parts[parts.length - 1];
        if (!mangaSlug || window.location.pathname.includes('/chapter-')) return;

        document.querySelectorAll('li.wp-manga-chapter').forEach(li => {
            li.style.cssText += ';border:2px solid transparent;background-image:linear-gradient(rgba(10,5,20,.95),rgba(10,5,20,.95)),linear-gradient(135deg,#a855f7,#7c3aed);background-origin:border-box;background-clip:padding-box,border-box;border-radius:8px;margin:5px 0;transition:0.3s;';
            li.addEventListener('mouseenter', () => { li.style.boxShadow='0 8px 16px rgba(168,85,247,.3)'; li.style.transform='translateY(-2px)'; });
            li.addEventListener('mouseleave', () => { li.style.boxShadow='none'; li.style.transform='translateY(0)'; });

            if (li.dataset.ghost_injected) return;
            const a = li.querySelector('a');
            if (!a) return;
            const m = a.textContent.trim().match(/Chapter\s+(\d+)/i);
            if (!m) return;

            li.dataset.ghost_injected = 'true';
            const url = `https://utoon.net/manga/${mangaSlug}/chapter-${m[1]}/`;
            li.style.position = 'relative';

            const ghost = document.createElement('a');
            ghost.href = url;
            ghost.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;z-index:9999999;cursor:pointer;background:transparent;';
            ghost.addEventListener('click', e => { e.preventDefault(); e.stopImmediatePropagation(); window.location.href = url; }, true);
            li.appendChild(ghost);
            a.style.pointerEvents = 'none';
        });
    }

    setInterval(injectGhostButtons, 1200);
    injectGhostButtons();
})();
