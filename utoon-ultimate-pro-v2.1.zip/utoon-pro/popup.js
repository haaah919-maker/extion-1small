document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('discord-btn')?.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://discord.com/users/@threads' });
    });
    document.getElementById('soc-discord')?.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://discord.com/users/@threads' });
    });

    document.getElementById('inject-btn')?.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
            const tab = tabs[0];
            if (!tab?.url?.includes('utoon.net')) {
                alert('افتح صفحة فصل على utoon.net أولاً');
                return;
            }
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['jspdf.min.js','jszip.min.js','config.js','api.js','effects.js','ui.js','download.js','settings.js','reader_logic.js']
            }).catch(err => {
                console.error('[Utoon] Inject failed:', err);
                alert('فشل التحميل: ' + err.message);
            });
        });
    });
});
