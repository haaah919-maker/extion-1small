// Utoon Ultimate Pro v2.1 - Main Orchestrator
// Requires: config.js, api.js, effects.js, ui.js, download.js, settings.js

async function injectReader() {
    if (window._u_reader_injected) return;
    window._u_reader_injected = true;

    const CFG      = window.UtoonConfig;
    const API      = window.UtoonAPI;
    const UI       = window.UtoonUI;
    const Download = window.UtoonDownload;
    const Effects  = window.UtoonEffects;
    const Settings = window.UtoonSettings;

    if (!CFG || !API || !UI || !Download || !Effects || !Settings) {
        console.error('[Utoon] Required modules not loaded.');
        return;
    }

    // ── Parse URL ───────────────────────────────────────────────────
    const pathParts   = window.location.pathname.split('/').filter(Boolean);
    const mangaSlug   = pathParts[pathParts.length - 2];
    const chapterSlug = pathParts[pathParts.length - 1];
    const mangaMainUrl = `${window.location.origin}/manga/${mangaSlug}/`;

    if (!mangaSlug || !chapterSlug) {
        console.warn('[Utoon] Could not parse manga/chapter from URL.');
        return;
    }

    // ── Fetch manga info & navigation ───────────────────────────────
    let allChapters = [], nextUrl = null, prevUrl = null, currentChObj = null;

    try {
        const info = await API.fetchMangaInfo(mangaSlug);
        if (info) {
            allChapters = info.chapters;
            const idx = allChapters.findIndex(c => (c.slug || '').includes(chapterSlug));
            if (idx !== -1) {
                currentChObj = allChapters[idx];
                if (idx < allChapters.length - 1) prevUrl = `${window.location.origin}/manga/${mangaSlug}/${allChapters[idx+1].slug}/`;
                if (idx > 0)                       nextUrl = `${window.location.origin}/manga/${mangaSlug}/${allChapters[idx-1].slug}/`;
            }
        }
    } catch (e) { console.warn('[Utoon] Manga info fetch failed:', e); }

    // ── Fetch images ─────────────────────────────────────────────────
    let imageUrls = [];
    try {
        imageUrls = await API.getAllChapterImages(mangaSlug, chapterSlug, currentChObj?.id_capitulo);
    } catch (e) {
        console.warn('[Utoon] Image fetch failed:', e);
        imageUrls = API.buildFallbackUrls(mangaSlug, chapterSlug);
    }

    const coverImg = document.querySelector('meta[property="og:image"]')?.content || '';

    // ── Build UI ──────────────────────────────────────────────────────
    UI.injectStyles();
    document.body.innerHTML = UI.buildReaderHTML(imageUrls, mangaSlug, chapterSlug, nextUrl, prevUrl, allChapters, coverImg);

    // ── Init effects ──────────────────────────────────────────────────
    Effects.init('effect-layer');

    // ── Wire UI ───────────────────────────────────────────────────────
    UI.setupPreloading(imageUrls);
    UI.setupProgressBar();
    UI.setupZoom();
    UI.setupFullscreen();
    UI.setupRTL();
    UI.setupAutoScroll();
    UI.setupSwipeNavigation(nextUrl, prevUrl);
    UI.setupKeyboard(nextUrl, prevUrl, mangaMainUrl);
    UI.setupHeaderAutoHide();
    UI.setupFAB(nextUrl);
    UI.scrollToFirstImage();

    // ── Navigation buttons ────────────────────────────────────────────
    const setNav = (id, url) => {
        const btn = document.getElementById(id);
        if (!btn) return;
        if (url) btn.addEventListener('click', () => window.location.href = url);
        else btn.disabled = true;
    };
    setNav('header-prev', prevUrl); setNav('header-next', nextUrl);
    setNav('footer-prev', prevUrl); setNav('footer-next', nextUrl);

    // Exit button
    document.getElementById('exit-btn')?.addEventListener('click', () => window.location.href = mangaMainUrl);

    // ── Theme handling ─────────────────────────────────────────────────
    const bgLayer   = document.getElementById('u-bg-layer');
    const bgUpload  = document.getElementById('bg-upload');
    const themeSel  = document.getElementById('theme-select');

    const applyTheme = (type, url = null) => {
        const def = CFG.THEMES[type];
        if (!def) return;
        if (type === 'custom') {
            if (url) bgLayer.style.background = `url(${url}) center/cover fixed`;
            else bgUpload?.click();
        } else if (type === 'manga') {
            bgLayer.style.background = coverImg
                ? `linear-gradient(rgba(10,5,20,0.88),rgba(10,5,20,0.88)), url('${coverImg}') center/cover fixed`
                : CFG.THEMES.default.background;
        } else {
            bgLayer.style.background = def.background;
        }
        bgLayer.style.backgroundSize = 'cover';
        bgLayer.style.backgroundPosition = 'center';
        bgLayer.style.backgroundAttachment = 'fixed';
        bgLayer.style.backgroundRepeat = 'no-repeat';

        // Update text color for light themes
        const main = document.getElementById('u-reader-main');
        if (main && def.text) main.style.color = def.text;

        Settings.setMultiple({ savedTheme: type, customBg: url });
    };

    themeSel?.addEventListener('change', e => applyTheme(e.target.value));
    bgUpload?.addEventListener('change', e => {
        const f = e.target.files[0];
        if (f) { const r = new FileReader(); r.onload = ev => applyTheme('custom', ev.target.result); r.readAsDataURL(f); }
    });

    // ── Effects select ────────────────────────────────────────────────
    document.getElementById('effect-select')?.addEventListener('change', e => Effects.startEffect(e.target.value));

    // ── Load saved settings ───────────────────────────────────────────
    Settings.getAll().then(res => {
        if (res.savedTheme)  { themeSel.value = res.savedTheme; applyTheme(res.savedTheme, res.customBg); }
        if (res.savedEffect) {
            const sel = document.getElementById('effect-select');
            if (sel) { sel.value = res.savedEffect; Effects.startEffect(res.savedEffect); }
        }
        if (res.readingDirection === 'rtl') {
            document.getElementById('u-reader-main')?.classList.add('rtl');
            const b = document.getElementById('btn-rtl');
            if (b) b.textContent = '➡️ LTR';
        }
    });

    // ── Download buttons ──────────────────────────────────────────────
    document.getElementById('btn-zip')?.addEventListener('click', async () => {
        UI.showToast('⏳ جاري تحميل ZIP…');
        await Download.downloadZIP(imageUrls, chapterSlug, mangaSlug, (done, total) => {
            if (done === total) UI.showToast('✅ ZIP جاهز!');
        });
    });

    document.getElementById('btn-pdf')?.addEventListener('click', async () => {
        UI.showToast('⏳ جاري تجهيز PDF…');
        await Download.downloadPDF(imageUrls, chapterSlug, mangaSlug, document.getElementById('btn-pdf'));
        UI.showToast('✅ PDF Ultra-HD جاهز!');
    });

    document.getElementById('btn-bulk')?.addEventListener('click', async () => {
        if (!allChapters?.length) { UI.showToast('⚠️ قائمة الفصول غير متاحة'); return; }
        const ans = prompt(
            `تحميل عدة فصول دفعة واحدة (ZIP)\nأدخل عدد الفصول (من الحالي):\n(المتاح: ${allChapters.length} فصل)`,
            '5'
        );
        if (!ans) return;
        const n = parseInt(ans);
        if (isNaN(n) || n < 1) { UI.showToast('⚠️ رقم غير صحيح'); return; }
        const cur = allChapters.findIndex(c => (c.slug||'').includes(chapterSlug));
        const toDownload = allChapters.slice(cur < 0 ? 0 : cur, (cur < 0 ? 0 : cur) + n);
        if (!toDownload.length) { UI.showToast('⚠️ لا فصول محددة'); return; }
        UI.showToast(`⏳ تحميل ${toDownload.length} فصول…`, 8000);
        try {
            await Download.downloadBulkZIP(toDownload, mangaSlug, (msg, done, total) => {
                if (msg) UI.showToast(msg, 4000);
            });
            UI.showToast('✅ Bulk ZIP جاهز!');
        } catch (e) {
            UI.showToast('❌ فشل التحميل الجماعي');
            console.error(e);
        }
    });

    // ── Save reading progress ─────────────────────────────────────────
    setInterval(() => Settings.saveProgress(mangaSlug, chapterSlug, window.scrollY), 5000);

    Settings.getProgress(mangaSlug).then(prog => {
        if (prog?.chapterSlug === chapterSlug && prog.scrollY > 150) {
            setTimeout(() => window.scrollTo({ top: prog.scrollY, behavior: 'smooth' }), 900);
        }
    });

    console.log(`[Utoon v2.1] ✅ ${mangaSlug}/${chapterSlug} — ${imageUrls.length} images | next:${nextUrl||'—'} prev:${prevUrl||'—'}`);
}

injectReader();
