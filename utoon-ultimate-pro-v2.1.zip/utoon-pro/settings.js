// Utoon Ultimate Pro v2.1 - Settings & Storage Module
window.UtoonSettings = (function() {
    const defaults = {
        savedTheme: 'default', savedEffect: 'off', customBg: null,
        autoScrollSpeed: 0, readingDirection: 'ltr',
        zoomLevel: 1, lastRead: {}
    };

    async function getAll() {
        return new Promise(resolve => {
            if (typeof chrome !== 'undefined' && chrome?.storage?.local) {
                chrome.storage.local.get(null, res => resolve({ ...defaults, ...res }));
            } else { resolve({ ...defaults }); }
        });
    }

    async function get(key) { return (await getAll())[key]; }

    async function set(key, value) {
        if (typeof chrome !== 'undefined' && chrome?.storage?.local)
            await chrome.storage.local.set({ [key]: value });
    }

    async function setMultiple(obj) {
        if (typeof chrome !== 'undefined' && chrome?.storage?.local)
            await chrome.storage.local.set(obj);
    }

    async function saveProgress(mangaSlug, chapterSlug, scrollY = 0) {
        const all = await getAll();
        const lr = all.lastRead || {};
        lr[mangaSlug] = { chapterSlug, scrollY, timestamp: Date.now() };
        await set('lastRead', lr);
    }

    async function getProgress(mangaSlug) {
        return ((await getAll()).lastRead || {})[mangaSlug] || null;
    }

    return { getAll, get, set, setMultiple, defaults, saveProgress, getProgress };
})();
