// Utoon Ultimate Pro v2.1 - UI Builder & Interaction Module
window.UtoonUI = (function() {
    const CFG = window.UtoonConfig;
    const API = window.UtoonAPI;
    const Settings = window.UtoonSettings;

    let state = {
        zoom: 1, autoScrollRAF: null, autoScrollActive: false,
        autoScrollSpeed: 0, pauseTimer: null, readingDirection: 'ltr',
        fullscreen: false, headerVisible: true
    };

    function injectStyles() {
        if (document.getElementById('u-reader-styles')) return;
        const s = document.createElement('style');
        s.id = 'u-reader-styles';
        s.innerHTML = `
        * { box-sizing: border-box; }
        #u-reader-main, #u-reader-main * { cursor: auto !important; }
        #header-controls { transition: transform 0.28s cubic-bezier(.22,.9,.17,1), opacity 0.28s; }
        #header-controls.u-hidden { transform: translateY(-130%); opacity: 0; pointer-events: none; }

        .u-btn-nav { padding:12px 28px; border-radius:8px; border:none; font-weight:700; cursor:pointer;
            transition:all 0.22s; color:white; font-size:14px; }
        .u-btn-nav:hover { transform:translateY(-2px); box-shadow:0 8px 18px rgba(168,85,247,0.25); }
        .u-btn-nav:disabled { background:#475569 !important; cursor:not-allowed; opacity:0.5; }
        .u-btn-nav:active { transform:scale(0.97); }

        .u-header-nav-btn { background:linear-gradient(135deg,#a855f7,#7c3aed); color:#fff; border:none;
            padding:8px 14px; border-radius:6px; font-weight:600; cursor:pointer; font-size:12px;
            box-shadow:0 4px 10px rgba(168,85,247,0.2); transition:all 0.2s; white-space:nowrap; }
        .u-header-nav-btn:hover { transform:translateY(-1px); box-shadow:0 6px 14px rgba(168,85,247,0.3); }
        .u-header-nav-btn:disabled { opacity:0.38; cursor:not-allowed; transform:none; }
        .u-header-nav-btn:active { transform:scale(0.96); }

        .u-reader-img { width:100%; display:block; transition:transform 0.2s; will-change:transform; }
        .u-img-wrapper { position:relative; overflow:hidden; min-height:150px;
            background:linear-gradient(90deg,#1a0d2e 25%,#2a1a4a 50%,#1a0d2e 75%);
            background-size:200% 100%; animation:u-shimmer 1.5s infinite; }
        .u-img-wrapper.loaded { animation:none; background:transparent; }
        @keyframes u-shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }

        #u-progress-container { position:fixed; top:0; left:0; width:100%; height:3px;
            background:rgba(168,85,247,0.15); z-index:10000002; pointer-events:none; }
        #u-progress-bar { height:100%; background:linear-gradient(90deg,#a855f7,#db2777);
            width:0%; transition:width 0.15s; }

        #u-zoom-controls { position:fixed; right:14px; bottom:100px; display:flex; flex-direction:column;
            gap:6px; z-index:10000003; opacity:0.75; transition:opacity 0.2s; }
        #u-zoom-controls:hover { opacity:1; }
        .u-zoom-btn { width:38px; height:38px; border-radius:50%; border:1px solid rgba(168,85,247,0.4);
            background:rgba(10,5,25,0.92); color:#fff; font-size:17px; cursor:pointer;
            display:flex; align-items:center; justify-content:center; transition:all 0.2s; }
        .u-zoom-btn:hover { background:#a855f7; transform:scale(1.12); }
        .u-zoom-btn:active { transform:scale(0.93); }

        #u-reader-main.rtl { direction:rtl; }
        #u-reader-main.rtl #header-controls { flex-direction:row-reverse; }
        #u-reader-main.rtl #nav-footer { flex-direction:row-reverse; }

        #u-fab { display:none; position:fixed; bottom:22px; right:22px; width:54px; height:54px;
            border-radius:50%; background:linear-gradient(135deg,#a855f7,#7c3aed); color:white;
            border:none; font-size:22px; z-index:10000004;
            box-shadow:0 8px 24px rgba(168,85,247,0.45); cursor:pointer; transition:transform 0.2s;
            align-items:center; justify-content:center; }
        #u-fab:active { transform:scale(0.93); }

        #u-toast { position:fixed; bottom:32px; left:50%; transform:translateX(-50%) translateY(100px);
            background:rgba(10,5,25,0.96); color:#d8b4fe; padding:10px 20px; border-radius:8px;
            border:1px solid rgba(168,85,247,0.35); font-size:13px; z-index:10000005;
            opacity:0; transition:all 0.3s; pointer-events:none; white-space:nowrap; }
        #u-toast.show { transform:translateX(-50%) translateY(0); opacity:1; }

        #u-chapter-title { font-size:13px; color:#a855f7; font-weight:700; letter-spacing:0.3px; }

        /* Scrollbar */
        ::-webkit-scrollbar { width:6px; }
        ::-webkit-scrollbar-track { background:rgba(168,85,247,0.05); }
        ::-webkit-scrollbar-thumb { background:rgba(168,85,247,0.3); border-radius:10px; }
        ::-webkit-scrollbar-thumb:hover { background:rgba(168,85,247,0.5); }

        /* ── Mobile ── */
        @media (max-width: 768px) {
            #header-controls { padding:8px 10px !important; gap:5px !important; flex-wrap:wrap !important; justify-content:flex-start !important; }
            .u-header-nav-btn { padding:6px 10px !important; font-size:11px !important; }
            #header-controls select { font-size:11px !important; padding:4px 6px !important; max-width:85px !important; }
            #img-container { margin:8px auto !important; border-radius:8px !important; max-width:100% !important; }
            .u-btn-nav { padding:10px 18px !important; font-size:13px !important; }
            #u-zoom-controls { right:8px; bottom:88px; }
            .u-zoom-btn { width:34px; height:34px; font-size:15px; }
            #u-fab { display:flex !important; }
            .u-autoscroll-box { display:none !important; }
            #header-controls .u-divider { display:none; }
            /* hide bulk on very small screens */
            @media (max-width:420px) { #btn-bulk { display:none !important; } }
        }
        @media (min-width: 769px) { #u-fab { display:none !important; } }
        `;
        document.head.appendChild(s);
    }

    function buildReaderHTML(imageUrls, mangaSlug, chapterSlug, nextUrl, prevUrl, allChapters, coverImg) {
        const themeOpts  = Object.entries(CFG.THEMES ).map(([k,v]) => `<option value="${k}">${v.name}</option>`).join('');
        const effectOpts = Object.entries(CFG.EFFECTS).map(([k,v]) => `<option value="${k}">${v.name}</option>`).join('');

        const titleDisplay = `${mangaSlug.replace(/-/g,' ')} › ${chapterSlug.replace(/-/g,' ')}`;

        const imgHTML = imageUrls.map((src, i) => `
            <div class="u-img-wrapper" data-index="${i}">
                <img src="${src}" class="u-reader-img"
                    loading="${i < 6 ? 'eager' : 'lazy'}"
                    ${i===0 ? 'id="first-img"' : ''}
                    onerror="this.parentElement.classList.add('loaded');if(this.src.endsWith('.jpg')){this.src=this.src.replace('.jpg','.webp');}else{this.parentElement.style.minHeight='0';this.style.display='none';}"
                    onload="this.parentElement.classList.add('loaded');">
            </div>`).join('');

        return `
        <div id="u-reader-main" style="background:#0a1014;color:#e2d9f3;display:flex;flex-direction:column;min-height:100vh;position:relative;z-index:9999999;overflow-x:hidden;">
            <div id="u-bg-layer" style="position:fixed;top:0;left:0;width:100%;height:100%;z-index:-1;transition:1s;background:linear-gradient(to bottom,#0a0514,#130a2a);background-size:cover;background-position:center;background-attachment:fixed;"></div>
            <div id="effect-layer" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:10000000;"></div>
            <div id="u-progress-container"><div id="u-progress-bar"></div></div>

            <!-- HEADER -->
            <div id="header-controls" style="position:sticky;top:0;width:100%;background:rgba(10,5,25,0.96);padding:10px 14px;border-bottom:2px solid #a855f7;z-index:10000001;display:flex;align-items:center;gap:10px;flex-wrap:wrap;backdrop-filter:blur(12px);">

                <!-- Nav -->
                <div style="display:flex;gap:6px;flex-shrink:0;">
                    <button id="header-prev" class="u-header-nav-btn" title="Back (← / A)">← Back</button>
                    <button id="header-next" class="u-header-nav-btn" title="Next (→ / D)">Next →</button>
                </div>

                <div class="u-divider" style="width:1px;height:22px;background:rgba(168,85,247,0.3);flex-shrink:0;"></div>

                <!-- Title -->
                <span id="u-chapter-title" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${titleDisplay}</span>

                <!-- Downloads -->
                <div style="display:flex;gap:6px;flex-shrink:0;flex-wrap:wrap;">
                    <button id="btn-zip"  class="u-header-nav-btn" style="background:linear-gradient(135deg,#a855f7,#7c3aed);">📦 ZIP</button>
                    <button id="btn-pdf"  class="u-header-nav-btn" style="background:linear-gradient(135deg,#db2777,#be185d);">📄 PDF</button>
                    <button id="btn-bulk" class="u-header-nav-btn" style="background:linear-gradient(135deg,#22c55e,#16a34a);font-size:11px;">📚 Bulk</button>
                </div>

                <div class="u-divider" style="width:1px;height:22px;background:rgba(168,85,247,0.3);flex-shrink:0;"></div>

                <!-- Effects -->
                <div style="display:flex;align-items:center;gap:5px;background:rgba(168,85,247,0.08);padding:5px 9px;border-radius:6px;border:1px solid rgba(168,85,247,0.35);flex-shrink:0;">
                    <select id="effect-select" style="background:transparent;color:#a855f7;border:none;cursor:pointer;font-size:12px;outline:none;font-weight:600;max-width:110px;">
                        ${effectOpts}
                    </select>
                </div>

                <!-- Auto-scroll (hidden on mobile via CSS class) -->
                <div class="u-autoscroll-box" style="display:flex;align-items:center;gap:5px;background:rgba(34,197,94,0.08);padding:5px 9px;border-radius:6px;border:1px solid #22c55e;flex-shrink:0;">
                    <span style="color:#22c55e;font-size:11px;font-weight:600;">Auto</span>
                    <input type="range" id="autoscroll-slider" min="${CFG.AUTO_SCROLL.min}" max="${CFG.AUTO_SCROLL.max}" step="${CFG.AUTO_SCROLL.step}" value="${CFG.AUTO_SCROLL.defaultValue}" style="width:80px;accent-color:#22c55e;cursor:pointer;">
                    <span id="autoscroll-label" style="color:#22c55e;font-size:11px;font-weight:600;min-width:28px;">OFF</span>
                </div>

                <!-- Theme -->
                <div style="display:flex;align-items:center;gap:5px;background:rgba(168,85,247,0.08);padding:5px 9px;border-radius:6px;border:1px solid rgba(168,85,247,0.35);flex-shrink:0;">
                    <select id="theme-select" style="background:transparent;color:#a855f7;border:none;cursor:pointer;font-size:12px;outline:none;font-weight:600;max-width:90px;">
                        ${themeOpts}
                    </select>
                    <input type="file" id="bg-upload" accept="image/*" style="display:none;">
                </div>

                <!-- Controls -->
                <div style="display:flex;gap:4px;flex-shrink:0;">
                    <button id="btn-rtl" class="u-header-nav-btn" style="background:#1e293b;border:1px solid #64748b;padding:6px 9px;font-size:11px;" title="Toggle RTL">⬅️ RTL</button>
                    <button id="btn-fs"  class="u-header-nav-btn" style="background:#1e293b;border:1px solid #64748b;padding:6px 9px;font-size:11px;" title="Fullscreen (F)">⛶</button>
                    <button id="exit-btn" class="u-header-nav-btn" style="background:#991b1b;border:1px solid #7f1d1d;padding:6px 9px;font-size:11px;" title="Exit (Esc)">✕</button>
                </div>
            </div>

            <!-- IMAGES -->
            <div id="img-container" style="max-width:850px;width:100%;margin:16px auto;background:rgba(0,0,0,0.8);box-shadow:0 0 60px rgba(0,0,0,0.85);border-radius:12px;overflow:hidden;">
                ${imgHTML}
                <div id="nav-footer" style="padding:28px 20px;display:flex;justify-content:center;gap:18px;background:rgba(10,5,25,0.98);border-top:2px solid #a855f7;flex-wrap:wrap;">
                    <button id="footer-prev" class="u-btn-nav" style="background:linear-gradient(135deg,#64748b,#475569);">← Back</button>
                    <button id="footer-next" class="u-btn-nav" style="background:linear-gradient(135deg,#a855f7,#7c3aed);">Next →</button>
                </div>
            </div>

            <!-- Zoom overlay -->
            <div id="u-zoom-controls">
                <button class="u-zoom-btn" id="zoom-in"    title="Zoom In (+)">+</button>
                <button class="u-zoom-btn" id="zoom-out"   title="Zoom Out (-)">−</button>
                <button class="u-zoom-btn" id="zoom-reset" title="Reset Zoom (Z)">⟲</button>
            </div>

            <!-- FAB (mobile) -->
            <button id="u-fab" title="Next Chapter">▶</button>
            <div id="u-toast"></div>
        </div>`;
    }

    /* ── Setup functions ── */

    function setupPreloading(imageUrls) {
        const imgs = document.querySelectorAll('#img-container img');
        const obs = new IntersectionObserver(entries => {
            entries.forEach(e => {
                if (e.isIntersecting) {
                    const idx = parseInt(e.target.closest('.u-img-wrapper')?.dataset.index || 0);
                    if (imageUrls[idx+1]) API.preloadImage(imageUrls[idx+1]);
                    if (imageUrls[idx+2]) API.preloadImage(imageUrls[idx+2]);
                }
            });
        }, { rootMargin: '500px 0px' });
        imgs.forEach(img => obs.observe(img));
    }

    function setupProgressBar() {
        const bar = document.getElementById('u-progress-bar');
        if (!bar) return;
        window.addEventListener('scroll', () => {
            const top = window.scrollY, h = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            bar.style.width = (h > 0 ? (top/h)*100 : 0) + '%';
        }, { passive: true });
    }

    function setupZoom() {
        const imgs = () => document.querySelectorAll('.u-reader-img');
        const apply = () => imgs().forEach(img => img.style.transform = `scale(${state.zoom})`);
        document.getElementById('zoom-in').onclick    = () => { state.zoom = Math.min(state.zoom+0.15, 3); apply(); };
        document.getElementById('zoom-out').onclick   = () => { state.zoom = Math.max(state.zoom-0.15, 0.4); apply(); };
        document.getElementById('zoom-reset').onclick = () => { state.zoom = 1; apply(); };

        // Pinch-to-zoom on mobile
        let initDist = 0, initZoom = 1;
        const container = document.getElementById('img-container');
        container.addEventListener('touchstart', e => {
            if (e.touches.length === 2) {
                initDist = Math.hypot(e.touches[0].pageX-e.touches[1].pageX, e.touches[0].pageY-e.touches[1].pageY);
                initZoom = state.zoom;
            }
        }, { passive: true });
        container.addEventListener('touchmove', e => {
            if (e.touches.length === 2) {
                const d = Math.hypot(e.touches[0].pageX-e.touches[1].pageX, e.touches[0].pageY-e.touches[1].pageY);
                state.zoom = Math.min(Math.max(initZoom * (d/initDist), 0.4), 3);
                apply();
            }
        }, { passive: true });
    }

    function setupFullscreen() {
        const btn = document.getElementById('btn-fs');
        if (!btn) return;
        btn.onclick = () => {
            const main = document.getElementById('u-reader-main');
            if (!document.fullscreenElement) {
                (main.requestFullscreen || main.webkitRequestFullscreen || main.mozRequestFullScreen).call(main);
                state.fullscreen = true; btn.textContent = '⛶ Exit';
            } else {
                (document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen).call(document);
                state.fullscreen = false; btn.textContent = '⛶';
            }
        };
        document.addEventListener('fullscreenchange', () => {
            if (!document.fullscreenElement) { state.fullscreen = false; btn.textContent = '⛶'; }
        });
    }

    function setupRTL() {
        const btn = document.getElementById('btn-rtl');
        const main = document.getElementById('u-reader-main');
        if (!btn || !main) return;
        btn.onclick = () => {
            main.classList.toggle('rtl');
            state.readingDirection = main.classList.contains('rtl') ? 'rtl' : 'ltr';
            btn.textContent = state.readingDirection === 'rtl' ? '➡️ LTR' : '⬅️ RTL';
            Settings.set('readingDirection', state.readingDirection);
        };
    }

    function setupAutoScroll() {
        const slider = document.getElementById('autoscroll-slider');
        const label  = document.getElementById('autoscroll-label');
        if (!slider || !label) return;

        function startAutoScroll() {
            if (state.autoScrollRAF) return;
            state.autoScrollActive = true;
            const step = () => {
                if (state.autoScrollActive && state.autoScrollSpeed > 0) window.scrollBy(0, state.autoScrollSpeed);
                state.autoScrollRAF = requestAnimationFrame(step);
            };
            state.autoScrollRAF = requestAnimationFrame(step);
        }
        function stopAutoScroll() {
            state.autoScrollActive = false;
            if (state.autoScrollRAF) { cancelAnimationFrame(state.autoScrollRAF); state.autoScrollRAF = null; }
        }
        function pauseTemp() {
            state.autoScrollActive = false;
            if (state.pauseTimer) clearTimeout(state.pauseTimer);
            if (state.autoScrollSpeed > 0)
                state.pauseTimer = setTimeout(() => { state.autoScrollActive = true; }, 600);
        }
        function updateLabel(v) {
            const n = parseFloat(v);
            if (n===0) label.textContent='OFF';
            else if (n<=3) label.textContent='Slow';
            else if (n<=7) label.textContent='Med';
            else if (n<=11) label.textContent='Fast';
            else label.textContent='MAX';
        }

        slider.oninput = e => {
            state.autoScrollSpeed = parseFloat(e.target.value);
            updateLabel(state.autoScrollSpeed);
            if (state.autoScrollSpeed === 0) stopAutoScroll();
            else { state.autoScrollActive = true; startAutoScroll(); }
            Settings.set('autoScrollSpeed', state.autoScrollSpeed);
        };

        document.addEventListener('mousemove', pauseTemp, { passive: true });
        document.addEventListener('wheel', pauseTemp, { passive: true });
        document.addEventListener('touchstart', pauseTemp, { passive: true });

        window._utoAutoScrollToggle = () => {
            if (state.autoScrollSpeed > 0) {
                slider.value = 0; updateLabel(0); state.autoScrollSpeed = 0; stopAutoScroll();
            } else {
                slider.value = 3; updateLabel(3); state.autoScrollSpeed = 3;
                state.autoScrollActive = true; startAutoScroll();
            }
        };

        Settings.get('autoScrollSpeed').then(v => {
            if (v !== undefined && v !== null) {
                state.autoScrollSpeed = v; slider.value = v; updateLabel(v);
                if (v > 0) { state.autoScrollActive = true; startAutoScroll(); }
            } else { updateLabel(0); }
        });
    }

    function setupSwipeNavigation(nextUrl, prevUrl) {
        let touchStartX = 0, touchStartY = 0;
        const container = document.getElementById('u-reader-main');
        if (!container) return;
        container.addEventListener('touchstart', e => {
            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;
        }, { passive: true });
        container.addEventListener('touchend', e => {
            const dx = e.changedTouches[0].screenX - touchStartX;
            const dy = Math.abs(e.changedTouches[0].screenY - touchStartY);
            if (Math.abs(dx) > 70 && dy < 50) {
                if (dx < 0 && nextUrl) { showToast('➡️ Next Chapter'); setTimeout(() => window.location.href = nextUrl, 300); }
                else if (dx > 0 && prevUrl) { showToast('⬅️ Back Chapter'); setTimeout(() => window.location.href = prevUrl, 300); }
            }
        }, { passive: true });
    }

    function setupKeyboard(nextUrl, prevUrl, mangaMainUrl) {
        document.addEventListener('keydown', e => {
            if (e.target.tagName === 'SELECT' || e.target.tagName === 'INPUT') return;
            const key = e.code;
            if (CFG.KEYS.prevChapter.includes(key)) { e.preventDefault(); if (prevUrl) window.location.href = prevUrl; }
            else if (CFG.KEYS.nextChapter.includes(key)) { e.preventDefault(); if (nextUrl) window.location.href = nextUrl; }
            else if (CFG.KEYS.toggleAutoScroll.includes(key)) { e.preventDefault(); window._utoAutoScrollToggle?.(); }
            else if (CFG.KEYS.fullscreen.includes(key)) { e.preventDefault(); document.getElementById('btn-fs')?.click(); }
            else if (CFG.KEYS.exit.includes(key)) { e.preventDefault(); if(document.fullscreenElement) document.exitFullscreen?.(); else window.location.href = mangaMainUrl; }
            else if (CFG.KEYS.toggleHeader.includes(key)) { e.preventDefault(); document.getElementById('header-controls').classList.toggle('u-hidden'); }
            else if (CFG.KEYS.zoomIn.includes(key)) { e.preventDefault(); document.getElementById('zoom-in')?.click(); }
            else if (CFG.KEYS.zoomOut.includes(key)) { e.preventDefault(); document.getElementById('zoom-out')?.click(); }
            else if (CFG.KEYS.resetZoom.includes(key)) { e.preventDefault(); document.getElementById('zoom-reset')?.click(); }
        });
    }

    function setupHeaderAutoHide() {
        const header = document.getElementById('header-controls');
        if (!header) return;
        let lastY = window.scrollY, ticking = false;
        window.addEventListener('scroll', () => {
            if (!ticking) {
                const y = window.scrollY;
                requestAnimationFrame(() => {
                    if (y > lastY + 12) header.classList.add('u-hidden');
                    else if (y < lastY - 12) header.classList.remove('u-hidden');
                    lastY = y; ticking = false;
                });
                ticking = true;
            }
        }, { passive: true });
        // Tap top area on mobile to show header
        document.addEventListener('touchend', e => {
            if (e.changedTouches[0].clientY < 60) header.classList.remove('u-hidden');
        }, { passive: true });
    }

    function setupFAB(nextUrl) {
        const fab = document.getElementById('u-fab');
        if (!fab) return;
        if (nextUrl) fab.onclick = () => { showToast('➡️ Next Chapter...'); setTimeout(() => window.location.href = nextUrl, 200); };
        else { fab.style.opacity = '0.3'; fab.style.pointerEvents = 'none'; }
    }

    function showToast(msg, duration = 2500) {
        const t = document.getElementById('u-toast');
        if (!t) return;
        t.textContent = msg;
        t.classList.add('show');
        clearTimeout(t._timer);
        t._timer = setTimeout(() => t.classList.remove('show'), duration);
    }

    function scrollToFirstImage() {
        setTimeout(() => {
            const first = document.getElementById('first-img');
            if (first) first.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 350);
    }

    return {
        injectStyles, buildReaderHTML,
        setupPreloading, setupProgressBar, setupZoom, setupFullscreen,
        setupRTL, setupAutoScroll, setupSwipeNavigation, setupKeyboard,
        setupHeaderAutoHide, setupFAB, showToast, scrollToFirstImage,
        getState: () => ({ ...state })
    };
})();
